/* eslint-disable @typescript-eslint/no-explicit-any */
import JoditEditor from 'jodit-react';
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Editor } from '@tinymce/tinymce-react';


interface Product {
  _id: string;
  name: string;
  type: 'book' | 'toy';
  price: number;
  category: string;
  ageRange: string;
  description: string;
}

interface CartItem extends Product {
  quantity: number;
}

const ShoppingCartIcon = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
  </svg>
);

const SearchIcon = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
  </svg>
);

const BookOpenIcon = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
  </svg>
);

const PuzzlePieceIcon = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 6.083c-.407-.331-.86-.583-1.346-.775a2.994 2.994 0 00-2.808 0c-.486.192-.939.444-1.346.775m4.499 0P9.75 6.083M14.25 6.083V3.75m-4.5 2.333V3.75m0 2.333a2.993 2.993 0 01-1.346-.775M9.75 6.083H7.5m2.25 0c.407.331.86.583 1.346.775a2.994 2.994 0 002.808 0c.486-.192.939-.444 1.346-.775m-4.5 11.834c-.407.331-.86.583-1.346.775a2.994 2.994 0 00-2.808 0c-.486-.192-.939-.444-1.346-.775m4.499 0P9.75 17.917m4.25 0V20.25m-4.5-2.333V20.25m0-2.333a2.993 2.993 0 01-1.346.775M9.75 17.917H7.5m9-6.75h2.25m-2.25 0c.407-.331.86-.583 1.346-.775a2.994 2.994 0 002.808 0c.486.192.939.444 1.346-.775M16.5 11.167V8.25m-4.5 2.917V8.25m0 2.917a2.993 2.993 0 01-1.346-.775M12 11.167H9.75M4.5 11.167h2.25m-2.25 0c-.407.331-.86.583-1.346.775A2.994 2.994 0 012.25 12c0 .897.394 1.703 1.031 2.275.486.192.939.444 1.346.775M4.5 11.167V8.25m15 2.917V8.25m0 2.917a2.993 2.993 0 001.346-.775M19.5 11.167h2.25" />
  </svg>
);

const categories = [
  { name: 'Picture Books', icon: <BookOpenIcon className="w-12 h-12 text-sky-500" /> },
  { name: 'Chapter Books', icon: <BookOpenIcon className="w-12 h-12 text-emerald-500" /> },
  { name: 'Educational Toys', icon: <PuzzlePieceIcon className="w-12 h-12 text-amber-500" /> },
  { name: 'Creative Play', icon: <PuzzlePieceIcon className="w-12 h-12 text-pink-500" /> },
];

const ProductCard: React.FC<{ product: Product; onAddToCart: (product: Product) => void }> = ({ product, onAddToCart }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col transform hover:scale-105 transition-transform duration-300">
      <div className="bg-slate-200 border-2 border-dashed border-slate-300 rounded-t-xl w-full h-48 flex items-center justify-center">
        {product.type === 'book' ?
          <BookOpenIcon className="w-16 h-16 text-slate-400" /> :
          <PuzzlePieceIcon className="w-16 h-16 text-slate-400" />}
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-semibold text-slate-800 mb-1 truncate" title={product.name}>{product.name}</h3>
        <p className="text-sm text-slate-600 mb-1">{product.category} - {product.ageRange}</p>
        <p className="text-xs text-slate-500 mb-2 h-10 overflow-hidden">{product.description}</p>
        <div className="mt-auto flex justify-between items-center">
          <p className="text-xl font-bold text-sky-600">${product.price.toFixed(2)}</p>
          <button
            onClick={() => onAddToCart(product)}
            className="bg-amber-400 text-amber-900 hover:bg-amber-500 font-semibold py-2 px-4 rounded-lg transition-colors duration-200 text-sm"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'books' | 'toys'>('all');
  const editorRef = useRef<any>(null);
  const log = () => {
    if (editorRef.current) {
      console.log(editorRef.current.getContent());
    }
  };

  const editor = useRef<any>(null);
  const [content, setContent] = useState('');

  useEffect(() => {
    // Fetch products from backend API
    fetch('http://localhost:5000/api/products')
      .then(res => res.json())
      .then(data => setProducts(data))
      .catch(() => {
        // fallback to empty array or mock data
        setProducts([]);
      });
  }, []);

  const handleAddToCart = (productToAdd: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item._id === productToAdd._id);
      if (existingItem) {
        return prevCart.map(item =>
          item._id === productToAdd._id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevCart, { ...productToAdd, quantity: 1 }];
    });
  };

  const cartItemCount = useMemo(() => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  }, [cart]);

  const filteredProducts = useMemo(() => {
    return products
      .filter(product =>
        activeTab === 'all' ||
        (activeTab === 'books' && product.type === 'book') ||
        (activeTab === 'toys' && product.type === 'toy')
      )
      .filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
  }, [products, searchTerm, activeTab]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-700 font-sans">
      {/* Header */}
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center">
              <BookOpenIcon className="h-8 w-8 text-sky-500 mr-2" />
              <span className="text-2xl font-bold text-sky-600">Kids<span className="text-amber-500">Wonderland</span></span>
            </div>
            <nav className="hidden md:flex space-x-6 items-center">
              <button onClick={() => setActiveTab('all')} className={`text-slate-600 hover:text-sky-500 transition-colors ${activeTab === 'all' ? 'text-sky-500 font-semibold' : ''}`}>Home</button>
              <button onClick={() => setActiveTab('books')} className={`hover:text-sky-500 transition-colors ${activeTab === 'books' ? 'text-sky-500 font-semibold' : 'text-slate-600'}`}>Books</button>
              <button onClick={() => setActiveTab('toys')} className={`hover:text-sky-500 transition-colors ${activeTab === 'toys' ? 'text-sky-500 font-semibold' : 'text-slate-600'}`}>Toys</button>
            </nav>
            <div className="flex items-center space-x-4">
              <div className="relative hidden sm:block">
                <input
                  type="text"
                  placeholder="Search books & toys..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-full rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-300 focus:border-sky-300 transition-shadow"
                />
                <SearchIcon className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
              </div>
              <button className="relative text-slate-600 hover:text-sky-500 transition-colors">
                <ShoppingCartIcon className="w-7 h-7" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </button>
            </div>
          </div>
          {/* Mobile Search Bar */}
          <div className="sm:hidden pb-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full rounded-lg border border-slate-300 focus:ring-2 focus:ring-sky-300 focus:border-sky-300 transition-shadow"
              />
              <SearchIcon className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            </div>
          </div>
        </div>
      </header>

      <div className='container mx-auto px-4 sm:px-6 lg:px-8 py-8'>
        <JoditEditor
          ref={editor}
          value={content}
          tabIndex={20}
          onChange={newContent => setContent(newContent)}
        />
      </div>

      <div className='container mx-auto px-4 sm:px-6 lg:px-8 py-8'>
        <Editor
          apiKey='szvsb3j972bv6ztvs28hf4r9kd9gz63sa203op71yb7mbxoo'
          onInit={(_evt, editor) => editorRef.current = editor}
          initialValue="<p>This is the initial content of the editor.</p>"
          init={{
            height: 300,
            menubar: false,
            plugins: [
              'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
              'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
              'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount'
            ],
            toolbar: 'undo redo | blocks | ' +
              'bold italic forecolor | alignleft aligncenter ' +
              'alignright alignjustify | bullist numlist outdent indent | ' +
              'removeformat | help',
            content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
          }}
        />
        <button className=' my-4 py-2 px-2 rounded-lg bg-gradient-to-r  from-sky-400 to-emerald-400 text-white text-xl hover:bg-gradient-to-r hover:from-sky-500 hover:to-emerald-500 cursor-pointer' onClick={log}>Log editor content</button>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-sky-400 to-emerald-400 text-white p-8 sm:p-12 rounded-xl shadow-lg mb-12 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">Welcome to a World of Wonder!</h1>
              <p className="text-lg sm:text-xl mb-6 max-w-xl">Explore magical books and playful toys that spark imagination and joy in every child.</p>
              <button className="bg-amber-400 text-amber-900 hover:bg-amber-500 font-bold py-3 px-6 rounded-lg text-lg transition-transform hover:scale-105 shadow-md">
                Discover Now
              </button>
            </div>
            <div className="hidden sm:block bg-white/20 border-2 border-dashed border-white/50 rounded-xl w-48 h-48 lg:w-64 lg:h-64 mt-6 sm:mt-0  items-center justify-center">
              <PuzzlePieceIcon className="w-24 h-24 text-white opacity-75" />
            </div>
          </div>
        </section>

        {/* Featured Products Section */}
        <section id="products" className="mb-12">
          <h2 className="text-3xl font-bold text-slate-800 mb-2 text-center">Our Treasures</h2>
          <p className="text-center text-slate-600 mb-8">Handpicked books and toys for endless fun and learning.</p>

          <div className="flex justify-center space-x-2 sm:space-x-4 mb-8">
            {['all', 'books', 'toys'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as 'all' | 'books' | 'toys')}
                className={`px-4 py-2 sm:px-6 sm:py-2 rounded-lg font-semibold transition-all duration-200 
                  ${activeTab === tab ? 'bg-sky-500 text-white shadow-md' : 'bg-white text-slate-600 hover:bg-sky-100 hover:text-sky-600'}`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
              {filteredProducts.map(product => (
                <ProductCard key={product._id} product={product} onAddToCart={handleAddToCart} />
              ))}
            </div>
          ) : (
            <p className="text-center text-slate-500 py-10 text-lg">No products found matching your criteria. Try a different search or category!</p>
          )}
        </section>

        {/* Shop by Category Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-slate-800 mb-8 text-center">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {categories.map(category => (
              <div key={category.name} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center text-center cursor-pointer hover:scale-105 transform">
                {category.icon}
                <h3 className="text-md sm:text-lg font-semibold text-slate-700 mt-4">{category.name}</h3>
              </div>
            ))}
          </div>
        </section>

        {/* Promotional Banner */}
        <section className="bg-amber-100 border-2 border-amber-300 p-8 rounded-xl shadow-lg mb-12 flex flex-col sm:flex-row items-center justify-between">
          <div>
            <h3 className="text-2xl font-bold text-amber-700 mb-2">Summer Reading Challenge!</h3>
            <p className="text-amber-600 mb-4 sm:mb-0">Join our challenge and win exciting prizes. Get 15% off on selected books!</p>
          </div>
          <button className="bg-emerald-500 text-white hover:bg-emerald-600 font-bold py-3 px-6 rounded-lg transition-colors duration-200 shadow-md whitespace-nowrap">
            Learn More
          </button>
        </section>

      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-slate-300 py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="text-lg font-semibold text-white mb-3">KidsWonderland</h4>
              <p className="text-sm">Bringing joy and learning to children everywhere.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-3">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-sky-300 transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-sky-300 transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-sky-300 transition-colors">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-white mb-3">Follow Us</h4>
              <div className="flex justify-center space-x-4">
                <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center text-sky-300 hover:bg-sky-500 hover:text-white transition-colors cursor-pointer">F</div>
                <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center text-sky-300 hover:bg-sky-500 hover:text-white transition-colors cursor-pointer">T</div>
                <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center text-sky-300 hover:bg-sky-500 hover:text-white transition-colors cursor-pointer">I</div>
              </div>
            </div>
          </div>
          <p className="text-sm border-t border-slate-700 pt-8">&copy; {new Date().getFullYear()} KidsWonderland. All rights reserved. Adventure Awaits!</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
