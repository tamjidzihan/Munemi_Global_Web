/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useRef, useMemo } from 'react';
import JoditEditor from 'jodit-react';

interface EditorProps {
    placeholder: string
}


const Editor = ({ placeholder }: EditorProps) => {
    const editor = useRef<any>(null);
    const [content, setContent] = useState('');

    const config = useMemo(() => ({
        readonly: false, // all options from https://xdsoft.net/jodit/docs/,
        placeholder: placeholder || 'Start typings...'
    }),
        [placeholder]
    );

    return (
        <JoditEditor
            ref={editor}
            value={content}
            config={config}
            tabIndex={1} // tabIndex of textarea
            onChange={newContent => setContent(newContent)}
        />
    );
};



export default Editor


